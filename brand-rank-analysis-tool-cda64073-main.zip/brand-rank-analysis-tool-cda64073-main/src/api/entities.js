import { base44 } from './base44Client';


export const BrandAudit = base44.entities.BrandAudit;

export const Company = base44.entities.Company;



// auth sdk:
export const User = base44.auth;