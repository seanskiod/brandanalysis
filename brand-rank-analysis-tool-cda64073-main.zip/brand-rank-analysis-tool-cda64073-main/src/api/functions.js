import { base44 } from './base44Client';


export const brandRanker = base44.functions.brandRanker;

export const getTopProgressiveCompanies = base44.functions.getTopProgressiveCompanies;

